from random import choice
from typing import Dict


class Collection:
	# Initialize the collection
	def __init__(self, coll: Dict = None):
		if coll is None:
			self.coll = {}
		else:
			if isinstance(coll, dict):
				self.coll = coll
			else:
				raise TypeError("Collection must be a dictionary.")

	# Getter and Setter

	# Setter
	def set(self, key, value):
		self.coll[key] = value

	# Getter
	def get(self, key):
		return self.coll[key]

	# Remove a key
	def remove(self, key):
		del self.coll[key]

	# Check whether contains certain key
	def contains(self, key):
		return key in self.coll

	# Check for collection size
	def size(self):
		return len(self.coll)

	# Check whether collection is empty
	def isEmpty(self):
		return self.size() == 0

	# Clear the collection
	def clear(self):
		self.coll = {}

	# Return all keys
	def keys(self):
		return self.coll.keys()

	# Return all values
	def values(self):
		return self.coll.values()

	# Return all items
	def items(self):
		return self.coll.items()

	# Return all keys as a list
	def __iter__(self):
		return iter(self.items())

	# Return a random key
	def randkey(self):
		return choice(list(self.coll.keys()))

	# Return a random value
	def random(self):
		return choice(list(self.coll.values()))

	# Return a random item
	def randitem(self):
		return choice(list(self.coll.items()))

	# Array-like methods
	# Methods that is basically similar to array methods

	# Return a value that matches the function
	def find(self, func):
		for key, value in self.coll.items():
			if func(value, key):
				return value

	# Return first value
	def first(self, num=0):
		return list(self.coll.values())[0 + num]

	# Return last value
	def last(self, num=0):
		return list(self.coll.values())[self.size() - 1 - num]

	# Remove all items that match the function
	def sweep(self, func):
		for key, value in self.coll.items():
			if func(value, key):
				self.remove(key)

	# Return a new collection with all items that match the function
	def filter(self, func):
		newcoll = Collection()
		for key, value in self.coll.items():
			if func(value, key):
				newcoll.set(key, value)
		return newcoll

	# Returns two collections with one that matches the function and vice-versa
	def partition(self, func):
		coll1 = Collection()
		coll2 = Collection()
		for key, value in self.coll.items():
			if func(value, key):
				coll1.set(key, value)
				self.remove(key)
			else:
				coll2.set(key, value)
				self.remove(key)
		return coll1, coll2

	# Returns a combined collection
	def combine(self, coll):
		if isinstance(coll, Collection):
			coll = coll.coll

			for key, value in coll.items():
				self.set(key, value)

			return self
		else:
			raise TypeError("Parameter must be an instance of Collection.")
